public class ThreadLocalEjemplo {

    private static ThreadLocal<Integer> threadLocal = ThreadLocal.withInitial(() -> 10);
    //private static ThreadLocal<Integer> threadLocal = new ThreadLocal<>();

    public static void main(String[] args) {

        Thread thread1 = new Thread(() -> {

            threadLocal.set(42);
            printData("Hilo 1");
            threadLocal.remove();
        });

        Thread thread2 = new Thread(() -> {

            threadLocal.set(99);
            printData("Hilo 2");
            threadLocal.remove();
        });


        thread1.start();
        thread2.start();


        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        printDataOutsideThreads();
    }

    private static void printData(String threadName) {

        Integer value = threadLocal.get();

        System.out.println("Hilo: " + threadName + ", Valor: " + value);
    }

    private static void printDataOutsideThreads() {

        Integer value = threadLocal.get();
        System.out.println("Fuera de los hilos, Valor: " + value);


        threadLocal.set(77);
        System.out.println("Fuera de los hilos, Nuevo Valor: " + threadLocal.get());


        threadLocal.remove();
        System.out.println("Fuera de los hilos, Valor después de remove: " + threadLocal.get());
    }
}
