ThreadLocal
Este proyecto Java proporciona un ejemplo práctico del uso de la clase ThreadLocal para gestionar variables
locales en hilos. La aplicación demuestra cómo cada hilo puede tener su propia instancia de una variable,
evitando interferencias entre hilos.

Contenido del Proyecto

El proyecto consta de los siguientes archivos:
ThreadLocalEjemplo.java: Contiene la implementación principal que demuestra el uso de ThreadLocal.

Ejecución
Para ejecutar la aplicación, sigue estos pasos:
1.Clona el repositorio o descarga el archivo ThreadLocalEjemplo.java.
2.Importar proyecto en IDE que puede ejecutar Java o terminal

Funcionamiento
La aplicación crea dos hilos (thread1 y thread2) que comparten una variable local utilizando ThreadLocal.
Cada hilo establece un valor diferente para esta variable y luego imprime el valor asociado a cada hilo.
Además, se demuestra cómo acceder a la variable local fuera de los hilos y realizar operaciones como la
eliminación de la variable local.

Resultado Esperado
La salida esperada de la aplicación es la siguiente:
Hilo: Hilo 2, Valor: 99
Hilo: Hilo 1, Valor: 42
Fuera de los hilos, Valor: 10
Fuera de los hilos, Nuevo Valor: 77
Fuera de los hilos, Valor después de remove: 10

Esto muestra que cada hilo tiene su propia instancia de la variable local y que los cambios en un hilo no
afectan a los demás hilos.

Detalles Adicionales
El método ThreadLocal.withInitial(() -> 10) se utiliza para inicializar la variable local con un valor
predeterminado de 10.
Se utiliza el método remove() para limpiar la variable local después de su uso en cada hilo.

Observaciones
Este ejemplo destaca la utilidad de ThreadLocal para evitar problemas de concurrencia al trabajar con
variables locales en entornos de hilos múltiples.

